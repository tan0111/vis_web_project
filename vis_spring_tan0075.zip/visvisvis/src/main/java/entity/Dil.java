
package entity;

import java.time.LocalDate;
import jakarta.persistence.Entity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import jakarta.persistence.*;

@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@Entity
@Table(name = "Dil")
public class Dil extends EntityBase {

    @Column(name = "season", nullable = false)
    private int season;

    @Column(name = "episode_number", nullable = false)
    private int episodeNumber;

    @Column(name = "length_episode", nullable = false)
    private int lengthEpisode;

    @ManyToOne
    @JoinColumn(name = "film_id", nullable = true)
    private FilmSerial filmSerial;

    public Dil(int season, int episodeNumber, int lengthEpisode, FilmSerial filmSerial) {
        this.season = season;
        this.episodeNumber = episodeNumber;
        this.lengthEpisode = lengthEpisode;
        this.filmSerial = filmSerial;
        this.setCreateDate(LocalDate.now());
        this.setLastUpdate(LocalDate.now());
    }
}
