
package entity;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.MappedSuperclass;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

//
//@Data
//@EqualsAndHashCode(callSuper = true)
//@NoArgsConstructor
//@Entity
//@Table(name = "User_a")
//public class User_a extends EntityBase {
//
//    @Column(unique = true, nullable = false)
//    private String email;
//    
//    @Column(nullable = false)
//    private String password;
//
//    @Column(nullable = false)
//    private boolean active;
//
//    @Column(name = "user_role")
//    private String user_role;
//
//    @Column(nullable = false)
//    private double balance;
//
//
//    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
//    private Set<Payment_info> payments = new HashSet<>();  
//
//
//    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
//    private Set<UserList> lists = new HashSet<>();  
//
//    public User_a(String email, String password, double balance, boolean active,  String user_role, Set<UserList> lists) {
//        this.email = email;
//        this.password = password;
//        this.balance = balance;
//        this.active = active;
//        this.user_role = user_role;
//        this.lists = lists != null ? lists : new HashSet<>();
//    }
//
//    public User_a(String email, String password, double balance, boolean active, String user_role) {
//        this(email, password, balance, active, user_role, new HashSet<>());
//    }
//    
//    
//    
//    
//    
//    
//    public boolean hasSufficientBalance(double amount) {
//        return this.balance >= amount;
//    }
//
//    public void deductBalance(double amount) {
//        if (hasSufficientBalance(amount)) {
//            this.balance -= amount;
//        } else {
//            throw new IllegalArgumentException("Insufficient balance");
//        }
//    }
//
//    public void addBalance(double amount) {
//        if (amount > 0) {
//            this.balance += amount;
//        }
//    }
//
//}


import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@Entity
@Table(name = "User_a")
public class User_a extends EntityBase  implements UserDetails {

    @Id
    @GeneratedValue
    private Long id;

    @Column(unique = true, nullable = false)
    private String email;

    @Column(nullable = false)
    private String password;

    @Column(name = "user_role", nullable = false)
    private String userRole; // 'USER', 'ADMIN', 'MANAGER'

    @Column(nullable = false)
    private double balance;

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<Payment_info> payments = new HashSet<>();  

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<UserList> lists = new HashSet<>();  

    public User_a(String email, String password, double balance, String userRole, Set<UserList> lists) {
        this.email = email;
        this.password = password;
        this.balance = balance;
        this.userRole = userRole;
        this.lists = lists != null ? lists : new HashSet<>();
    }

    public User_a(String email, String password, double balance, String userRole) {
        this(email, password, balance, userRole, new HashSet<>());
    }

    // Custom methods for handling balance
    public boolean hasSufficientBalance(double amount) {
        return this.balance >= amount;
    }

    public void deductBalance(double amount) {
        if (hasSufficientBalance(amount)) {
            this.balance -= amount;
        } else {
            throw new IllegalArgumentException("Insufficient balance");
        }
    }

    public void addBalance(double amount) {
        if (amount > 0) {
            this.balance += amount;
        }
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        Set<SimpleGrantedAuthority> authorities = new HashSet<>();
        // Assign role authority based on the userRole
        authorities.add(new SimpleGrantedAuthority("ROLE_" + this.userRole));
        return authorities;
    }

    @Override
    public String getUsername() {
        return email; // Email is the unique identifier
    }

}























