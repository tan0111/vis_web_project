package entity;


import java.io.Serializable;
import java.time.LocalDate;
import jakarta.persistence.*;

import jakarta.persistence.MappedSuperclass;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@MappedSuperclass
@Data
@NoArgsConstructor
public class EntityBase implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "last_update", nullable = false)
    private LocalDate lastUpdate;

    @Column(name = "create_date", updatable = false, nullable = false)
    private LocalDate createDate;

    @PrePersist
    protected void onCreate() {
        createDate = LocalDate.now();
        lastUpdate = LocalDate.now();
    }

    @PreUpdate
    protected void onUpdate() {
        lastUpdate = LocalDate.now();
    }
}
