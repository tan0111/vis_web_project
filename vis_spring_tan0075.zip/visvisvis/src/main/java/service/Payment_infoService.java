//package service;
//
//import entity.User_a;
//import jakarta.persistence.EntityNotFoundException;
//import jakarta.transaction.Transactional;
//import entity.Payment_info;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//import repositories.UserRepository;
//import repositories.PaymentRepository;
//
//@Service
//@Transactional
//public class Payment_infoService {
//
//    @Autowired
//    private UserRepository userRepository;
//
//    @Autowired
//    private PaymentRepository paymentInfoRepository;
//
//    // Process payment for a user
//    public void processPayment(Long userId, double amount) {
//        // Validate user exists
//        User_a user = userRepository.findById(userId)
//                .orElseThrow(() -> new EntityNotFoundException("User not found"));
//
//        // Check if user has sufficient balance
//        if (!user.hasSufficientBalance(amount)) {
//            throw new IllegalArgumentException("Insufficient balance");
//        }
//
//        user.deductBalance(amount);
//
//        Payment_info paymentInfo = new Payment_info();
//        paymentInfo.setUser(user);
//        paymentInfo.setPaymentAmount(amount);
//        
//        paymentInfo.setPaymentStatus("SUCCESS"); 
//        
//        paymentInfoRepository.save(paymentInfo);
//
//        userRepository.save(user);
//    }
//}
