package service;

import entity.Actor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import repositories.ActorRepository;

import java.util.List;

@Service
public class ActorService {

    @Autowired
    private ActorRepository repository;

    public Actor saveActor(Actor actor) {
        validateActor(actor);
        return repository.save(actor);
    }

    public List<Actor> saveActors(List<Actor> actors) {
        for (Actor actor : actors) {
            validateActor(actor);
        }
        return repository.saveAll(actors);
    }

    public List<Actor> getActors() {
        return repository.findAll();
    }

    public Actor getActorById(Long id) {
        return repository.findById(id).orElse(null);
    }

    public Actor getActorByFirstName(String firstName) {
        return repository.findByFirstName(firstName);
    }

    public Actor getActorByLastName(String lastName) {
        return repository.findByLastName(lastName);
    }

    public String deleteActor(Long id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
            return "Actor removed! ID: " + id;
        }
        return "Actor not found! ID: " + id;
    }

    public Actor updateActor(Long id, Actor actor) {
        Actor existingActor = repository.findById(id).orElse(null);

        if (existingActor != null) {
            validateActor(actor);
            existingActor.setFirstName(actor.getFirstName());
            existingActor.setLastName(actor.getLastName());
            return repository.save(existingActor);
        }
        return null;
    }

    private void validateActor(Actor actor) {
        if (actor.getFirstName() == null || actor.getFirstName().isEmpty()) {
            throw new IllegalArgumentException("First name cannot be null or empty");
        }
        if (actor.getLastName() == null || actor.getLastName().isEmpty()) {
            throw new IllegalArgumentException("Last name cannot be null or empty");
        }
    }
}
