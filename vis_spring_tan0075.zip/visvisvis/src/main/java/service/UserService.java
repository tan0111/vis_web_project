package service;

import entity.User_a;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import repositories.UserRepository;

import java.util.List;
import entity.User_a;
import repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;


    @Autowired
    private PasswordEncoder passwordEncoder;

    // Save a single user
    public User_a saveUser(User_a user) {
        return userRepository.save(user);
    }

    // Save multiple users
    public List<User_a> saveUsers(List<User_a> users) {
        return userRepository.saveAll(users);
    }

    // Get all users
    public List<User_a> getUsers() {
        return userRepository.findAll();
    }

    // Get user by ID
    public User_a getUserById(Long userId) {
        return userRepository.findById(userId).orElse(null);
    }

    // Update user
    public User_a updateUser(User_a user) {
        if (userRepository.existsById(user.getId())) {
            return userRepository.save(user);
        }
        return null;
    }

    // Delete user
    public String deleteUser(Long userId) {
        if (userRepository.existsById(userId)) {
            userRepository.deleteById(userId);
            return "User removed! ID: " + userId;
        }
        return "User not found! ID: " + userId;
    }
    
    
    
    
    
    
    
    
    
    public void registerUser(String email, String rawPassword, String role, double balance) {
        User_a user = new User_a();
        user.setEmail(email);
        user.setPassword(passwordEncoder.encode(rawPassword));
        user.setUserRole(role.toUpperCase()); // Role should be in uppercase
        user.setBalance(balance);

        userRepository.save(user);
    }

}
