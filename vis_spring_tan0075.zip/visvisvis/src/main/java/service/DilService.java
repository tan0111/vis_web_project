
package service;

import entity.Dil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import repositories.DilRepository;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class DilService {

    @Autowired
    private DilRepository dilRepository;

    public Dil saveDil(Dil dil) {
        validateDil(dil);
        return dilRepository.save(dil);
    }

    public List<Dil> saveDils(List<Dil> dils) {
        for (Dil dil : dils) {
            validateDil(dil);
        }
        return dilRepository.saveAll(dils);
    }

    public List<Dil> getDils() {
        return dilRepository.findAll();
    }

    public Dil getDilById(Long id) {
        return dilRepository.findById(id).orElse(null);
    }

    public String deleteDil(Long id) {
        if (dilRepository.existsById(id)) {
            dilRepository.deleteById(id);
            return "Dil removed! ID: " + id;
        }
        return "Dil not found! ID: " + id;
    }

    public Dil updateDil(Long id, Dil dil) {
        Dil existingDil = dilRepository.findById(id).orElse(null);

        if (existingDil != null) {
            validateDil(dil);
            existingDil.setSeason(dil.getSeason());
            existingDil.setEpisodeNumber(dil.getEpisodeNumber());
            existingDil.setLengthEpisode(dil.getLengthEpisode());
            existingDil.setFilmSerial(dil.getFilmSerial());
            return dilRepository.save(existingDil);
        }
        return null;
    }

    private void validateDil(Dil dil) {
        if (dil.getSeason() <= 0) {
            throw new IllegalArgumentException("Season must be greater than 0");
        }
        if (dil.getEpisodeNumber() <= 0) {
            throw new IllegalArgumentException("Episode number must be greater than 0");
        }
        if (dil.getLengthEpisode() <= 0) {
            throw new IllegalArgumentException("Episode length must be greater than 0");
        }
        if (dil.getFilmSerial() == null) {
            throw new IllegalArgumentException("Film serial cannot be null");
        }
    }
}
