package service;

import entity.Category;
import repositories.CategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CategoryService {

    @Autowired
    private CategoryRepository repository;

    public Category saveCategory(Category category) {
        validateCategory(category);
        return repository.save(category);
    }

    public List<Category> saveCategories(List<Category> categories) {
        for (Category category : categories) {
            validateCategory(category);
        }
        return repository.saveAll(categories);
    }

    public List<Category> getCategories() {
        return repository.findAll();
    }

    public Category getCategoryById(Long id) {
        return repository.findById(id).orElse(null);
    }

    public Category getCategoryByName(String name) {
        return repository.findByCategoryName(name);
    }

    public String deleteCategory(Long id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
            return "Category removed! ID: " + id;
        }
        return "Category not found! ID: " + id;
    }

    public Category updateCategory(Long id, Category category) {
        Category existingCategory = repository.findById(id).orElse(null);

        if (existingCategory != null) {
            validateCategory(category);
            existingCategory.setCategoryName(category.getCategoryName());
            return repository.save(existingCategory);
        }
        return null;
    }

    private void validateCategory(Category category) {
        if (category.getCategoryName() == null || category.getCategoryName().isEmpty()) {
            throw new IllegalArgumentException("Category name cannot be null or empty");
        }
    }
}
