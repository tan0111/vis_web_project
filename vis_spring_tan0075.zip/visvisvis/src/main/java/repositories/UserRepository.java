package repositories;

import entity.User_a;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<User_a, Long>, JpaSpecificationExecutor<User_a> {
//	User_a findByEmail(String email);  
    Optional<User_a> findByEmail(String email); // Query to find by email
    
    
    @Query("SELECT u FROM User_a u WHERE u.userRole = 'ADMIN'")
    List<User_a> findOnlyAdmins();
    @Query("SELECT u FROM User_a u WHERE u.userRole = 'MANAGER'")
    List<User_a> findOnlyManagers();

}