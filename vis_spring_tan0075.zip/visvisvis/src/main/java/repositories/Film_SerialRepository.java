package repositories;

import entity.FilmSerial;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface Film_SerialRepository extends JpaRepository<FilmSerial, Long>, JpaSpecificationExecutor<FilmSerial> {

}