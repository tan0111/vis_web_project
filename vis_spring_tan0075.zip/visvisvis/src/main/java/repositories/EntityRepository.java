package repositories;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

//import cz.vsb.fei.lab005.entities.EntityBase;
//import cz.vsb.fei.lab005.entities.Person;
import entity.EntityBase;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;

@Repository
public abstract class EntityRepository<T extends EntityBase> implements JpaRepository<T, Long>, JpaSpecificationExecutor<T>, Serializable {
    private static final long serialVersionUID = 1L;

    protected abstract Class<T> getClazz();

    @Transactional
    public T save(T entity) {
        if (entity.getId() == null || entity.getId() == 0) {
            return saveAndFlush(entity);
        } else {
            return save(entity);
        }
    }

    public long count() {
        return findAll().size();
    }

    public long count(Map<String, String> filterBy) {
        // Implementace filtrování
        return findAll((root, query, cb) -> {
            List<Predicate> filters = new ArrayList<>();
            for (Map.Entry<String, String> filter : filterBy.entrySet()) {
                String fieldName = filter.getKey();
                String filterValue = filter.getValue();
                if (filterValue != null) {
                    filters.add(cb.equal(root.get(fieldName), filterValue));
                }
            }
            return cb.and(filters.toArray(new Predicate[0]));
        }).size();
    }

    public List<T> findAll() {
        return findAll();
    }

    public List<T> findAll(int first, int pageSize) {
        Pageable pageable = PageRequest.of(first / pageSize, pageSize);
        return findAll(pageable).getContent();
    }

    public List<T> findAll(int first, int pageSize, Map<String, String> sortBy, Map<String, String> filterBy) {
        Pageable pageable = PageRequest.of(first / pageSize, pageSize);
        return findAll((root, query, cb) -> {
            List<Predicate> filters = new ArrayList<>();
            for (Map.Entry<String, String> filter : filterBy.entrySet()) {
                String fieldName = filter.getKey();
                String filterValue = filter.getValue();
                if (filterValue != null) {
                    filters.add(cb.equal(root.get(fieldName), filterValue));
                }
            }
            return cb.and(filters.toArray(new Predicate[0]));
        }, pageable).getContent();
    }

    @Transactional
    public void delete(T entity) {
        deleteById(entity.getId());
    }

    public T refresh(T entity) {
        return findById(entity.getId()).orElse(null);
    }
}
