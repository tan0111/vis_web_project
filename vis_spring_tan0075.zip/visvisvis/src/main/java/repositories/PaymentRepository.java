package repositories;

import entity.User_a;
import entity.Payment_info;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface PaymentRepository extends JpaRepository<Payment_info, Long>, JpaSpecificationExecutor<Payment_info> {
   // List<Payment_info> findByUserId(Long userId);

}