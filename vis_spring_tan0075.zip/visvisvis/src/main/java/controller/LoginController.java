package controller;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class LoginController {

    @GetMapping("/login")
    public String showLoginPage() {
        System.out.println("Login page endpoint hit!");
        return "login"; 
    }

    @GetMapping("/index")
    public String home() {
        return "index";  
    }
    @GetMapping("/signup")
    public String homesign() {
        return "signup";  
    }


    @RequestMapping("/logout")
    public String logout() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null) {
            SecurityContextHolder.clearContext();  // Clear authentication context to log out user
        }
        return "redirect:/login?logout";  // Redirect to login page with a logout message
    }
}
