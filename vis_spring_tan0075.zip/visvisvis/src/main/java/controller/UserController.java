package controller;

import entity.User_a;
import service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/addUser")
    public User_a addUser(@RequestBody User_a user) {
        return userService.saveUser(user);
    }

    @PostMapping("/addUsers")
    public List<User_a> addUsers(@RequestBody List<User_a> users) {
        return userService.saveUsers(users);
    }

    @GetMapping("/users")
    public List<User_a> findAllUsers() {
        return userService.getUsers();
    }

    @GetMapping("/user/{id}")
    public User_a findUserById(@PathVariable Long id) {
        return userService.getUserById(id);
    }

    @PutMapping("/update")
    public User_a updateUser(@RequestBody User_a user) {
        return userService.updateUser(user);
    }

    @DeleteMapping("/delete/{userId}")
    public String deleteUser(@PathVariable Long userId) {
        return userService.deleteUser(userId);
    }
}
