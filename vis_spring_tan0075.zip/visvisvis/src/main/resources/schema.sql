DROP TABLE Dil CASCADE CONSTRAINTS;
DROP TABLE User_List CASCADE CONSTRAINTS;
DROP TABLE Payment_Info CASCADE CONSTRAINTS;
DROP TABLE UserListFilm CASCADE CONSTRAINTS;
DROP TABLE User_a CASCADE CONSTRAINTS;
DROP TABLE Actor_film CASCADE CONSTRAINTS;
DROP TABLE Category_film CASCADE CONSTRAINTS;
DROP TABLE Film CASCADE CONSTRAINTS;
DROP TABLE Actor CASCADE CONSTRAINTS;
DROP TABLE Category CASCADE CONSTRAINTS; 

CREATE TABLE Actor (
    actor_id NUMBER PRIMARY KEY,
    actor_fname CHAR(100),
    actor_lname CHAR(100)
);

CREATE TABLE Category (
    category_id NUMBER PRIMARY KEY,
    category_name CHAR(100)
);

CREATE TABLE Film (
    film_id NUMBER PRIMARY KEY,
    title CHAR(100),
    reziser CHAR(100),
    description CHAR(500),
    release_year CHAR(4),
    length_film NUMBER
);

CREATE TABLE Actor_film (
    actor_id NUMBER,
    film_id NUMBER,
    PRIMARY KEY (actor_id, film_id),
    CONSTRAINT FK_Actor_Film_Actor_UQ FOREIGN KEY (actor_id) REFERENCES Actor(actor_id),
    CONSTRAINT FK_Actor_Film_Film_UQ FOREIGN KEY (film_id) REFERENCES Film(film_id)
);

CREATE TABLE Category_film (
    category_id NUMBER,
    film_id NUMBER,
    PRIMARY KEY (category_id, film_id),
    CONSTRAINT FK_Category_Film_Category_UQ FOREIGN KEY (category_id) REFERENCES Category(category_id),
    CONSTRAINT FK_Category_Film_Film_UQ FOREIGN KEY (film_id) REFERENCES Film(film_id)
);


CREATE TABLE User_a (
    user_id NUMBER PRIMARY KEY,
    email CHAR(100),
    heslo CHAR(100),
    user_role CHAR(40), 
    balance DOUBLE DEFAULT 0
);

CREATE TABLE User_List (
    list_id NUMBER PRIMARY KEY,
    name CHAR(100) NOT NULL,
    description CHAR(500),
    user_id NUMBER NOT NULL,
    CONSTRAINT FK_UserList_User FOREIGN KEY (user_id) REFERENCES User_a(user_id)
);


CREATE TABLE UserListFilm (
    user_id NUMBER,
    film_id NUMBER,
    list_id NUMBER,
    PRIMARY KEY (user_id, film_id, list_id),
    CONSTRAINT FK_UserListFilm_User FOREIGN KEY (user_id) REFERENCES User_a(user_id),
    CONSTRAINT FK_UserListFilm_Film FOREIGN KEY (film_id) REFERENCES Film(film_id),
    CONSTRAINT FK_UserListFilm_UserList FOREIGN KEY (list_id) REFERENCES User_List(list_id)
);

CREATE TABLE Payment_Info (
    payment_id NUMBER PRIMARY KEY,               
    user_id NUMBER NOT NULL,                    
    payment_amount NUMBER NOT NULL,             
    payment_status CHAR(10) NOT NULL,          
    FOREIGN KEY (user_id) REFERENCES User_a(user_id) 
);

CREATE TABLE Dil (
    dil_id NUMBER PRIMARY KEY,
    season NUMBER NOT NULL,
    episode_number NUMBER NOT NULL,
    length_episode NUMBER NOT NULL,
    film_id NUMBER NULL,
    create_date DATE NOT NULL,
    last_update DATE NOT NULL,
    CONSTRAINT FK_Dil_FilmSerial FOREIGN KEY (film_id) REFERENCES Film(film_id)
);

