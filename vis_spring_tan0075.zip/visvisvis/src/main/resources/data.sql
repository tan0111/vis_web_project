INSERT INTO Actor (actor_id, actor_fname, actor_lname) VALUES (1, 'Robert', 'Downey Jr.');
INSERT INTO Actor (actor_id, actor_fname, actor_lname) VALUES (2, 'Chris', 'Evans');
INSERT INTO Actor (actor_id, actor_fname, actor_lname) VALUES (3, 'Scarlett', 'Johansson');

INSERT INTO Category (category_id, category_name) VALUES (1, 'Action');
INSERT INTO Category (category_id, category_name) VALUES (2, 'Drama');

INSERT INTO Film (film_id, title, reziser, description, release_year, length_film) VALUES (1, 'Iron Man', 'Jon Favreau', 'A billionaire industrialist and genius inventor, Tony Stark (Iron Man).', '2008', 126);
INSERT INTO Film (film_id, title, reziser, description, release_year, length_film) VALUES (2, 'The Avengers', 'Joss Whedon', 'Earths mightiest heroes must come together.', '2012', 143);

INSERT INTO Actor_film (actor_id, film_id) VALUES (1, 1);
INSERT INTO Actor_film (actor_id, film_id) VALUES (1, 2);

INSERT INTO Category_film (category_id, film_id) VALUES (1, 1);
INSERT INTO Category_film (category_id, film_id) VALUES (1, 2);
INSERT INTO Category_film (category_id, film_id) VALUES (2, 2);

INSERT INTO User_a (user_id, email, heslo, user_role) VALUES (1, 'john.doe@example.com', 'pass123', 'USER');
INSERT INTO User_a (user_id, email, heslo, user_role) VALUES (2, 'jane.doe@film_admin.com', 'pass456', 'ADMIN');
INSERT INTO User_a (user_id, email, heslo, user_role) VALUES (3, 'jads.doe@film_manager.com', 'passw456', 'MANAGER');
INSERT INTO User_a (user_id, email, heslo, user_role) VALUES (4, 'joane.doe@email.com', 'pas123', 'USER');


INSERT INTO Payment_Info (payment_id, user_id, payment_amount, payment_status)
VALUES (1, 1, 100.00, 'Success');


INSERT INTO User_List (list_id, name, description, user_id) VALUES (1, 'Weekend Movies', 'Films perfect for relaxing over the weekend.', 1);
INSERT INTO User_List (list_id, name, description, user_id) VALUES (2, 'Action Movies', 'Action-packed films to get the adrenaline pumping.', 1);
INSERT INTO User_List (list_id, name, description, user_id) VALUES (3, 'Superhero Movies', 'Best superhero films ever!', 2);
INSERT INTO User_List (list_id, name, description, user_id) VALUES (4, 'Must Watch', 'Films that you absolutely can’t miss.', 2);



-- User 1 - 'Weekend Movies' list (list_id = 1)
INSERT INTO UserListFilm (user_id, film_id, list_id) VALUES (1, 1, 1);  -- Iron Man in 'Weekend Movies'
INSERT INTO UserListFilm (user_id, film_id, list_id) VALUES (1, 2, 1);  -- The Avengers in 'Weekend Movies'

-- User 1 - 'Action Movies' list (list_id = 2)
INSERT INTO UserListFilm (user_id, film_id, list_id) VALUES (1, 1, 2);  -- Iron Man in 'Action Movies'
INSERT INTO UserListFilm (user_id, film_id, list_id) VALUES (1, 2, 2);  -- The Avengers in 'Action Movies'

-- User 2 - 'Superhero Movies' list (list_id = 3)
INSERT INTO UserListFilm (user_id, film_id, list_id) VALUES (2, 1, 3);  -- Iron Man in 'Superhero Movies'
INSERT INTO UserListFilm (user_id, film_id, list_id) VALUES (2, 2, 3);  -- The Avengers in 'Superhero Movies'

-- User 2 - 'Must Watch' list (list_id = 4)
INSERT INTO UserListFilm (user_id, film_id, list_id) VALUES (2, 1, 4);  -- Iron Man in 'Must Watch'
INSERT INTO UserListFilm (user_id, film_id, list_id) VALUES (2, 2, 4);  -- The Avengers in 'Must Watch'


INSERT INTO Dil (dil_id, season, episode_number, length_episode, film_id, create_date, last_update)
VALUES (1, 1, 1, 42, 1, SYSDATE, SYSDATE);

INSERT INTO Dil (dil_id, season, episode_number, length_episode, film_id, create_date, last_update)
VALUES (2, 1, 2, 45, 1, SYSDATE, SYSDATE);

INSERT INTO Dil (dil_id, season, episode_number, length_episode, film_id, create_date, last_update)
VALUES (3, 2, 1, 50, 2, SYSDATE, SYSDATE);

INSERT INTO Dil (dil_id, season, episode_number, length_episode, film_id, create_date, last_update)
VALUES (4, 2, 2, 48, 2, SYSDATE, SYSDATE);

INSERT INTO Dil (dil_id, season, episode_number, length_episode, film_id, create_date, last_update)
VALUES (5, 3, 1, 55, 1, SYSDATE, SYSDATE);

INSERT INTO Dil (dil_id, season, episode_number, length_episode, film_id, create_date, last_update)
VALUES (6, 3, 2, 52, 1, SYSDATE, SYSDATE);

