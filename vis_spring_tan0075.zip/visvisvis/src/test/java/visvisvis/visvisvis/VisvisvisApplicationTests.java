package visvisvis.visvisvis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VisvisvisApplicationTests {

	@Test
	void contextLoads() {
	}

}
